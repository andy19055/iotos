<template>
  <div id="app">
    <Example/>
  </div>
</template>

<script>
  import Example from './components/Example'

  export default {
    name: 'App',
    components: {
      Example
    }
  }
</script>

<style>
</style>
